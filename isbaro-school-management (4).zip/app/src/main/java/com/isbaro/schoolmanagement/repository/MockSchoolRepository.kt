package com.isbaro.schoolmanagement.repository

import com.isbaro.schoolmanagement.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

object MockSchoolRepository : SchoolRepository {
    private val _currentSession = MutableStateFlow<UserSession?>(
        UserSession("usr-01", "Yahye (Super Admin)", "yahy38989@gmail.com", UserRole.SUPER_ADMIN, "sch-01", "Isbaro International Academy")
    )
    override val currentSession: StateFlow<UserSession?> = _currentSession.asStateFlow()

    override fun switchRole(role: UserRole) {
        val base = _currentSession.value ?: return
        val newName = when (role) {
            UserRole.SUPER_ADMIN -> "Yahye (Super Admin)"
            UserRole.SCHOOL_ADMIN -> "Principal Hassan"
            UserRole.TEACHER -> "Ustadh Farhan"
            UserRole.STUDENT -> "Amina Abdi"
            UserRole.PARENT -> "Khadija Warsame"
        }
        _currentSession.value = base.copy(role = role, name = newName)
    }

    private val schools = mutableListOf(
        SchoolRecord("sch-01", "ISB-HQ01", "ACC-9921", "Isbaro International Academy", "Active", "Premium", 1250, "2027-12-31"),
        SchoolRecord("sch-02", "BAN-0082", "ACC-4412", "Banadir Excellence School", "Active", "Standard", 740, "2027-08-15"),
        SchoolRecord("sch-03", "HOD-1190", "ACC-7730", "Hodan Modern College", "Suspended", "Basic", 320, "2026-11-01"),
        SchoolRecord("sch-04", "WBD-3301", "ACC-1209", "Waberi STEM Academy", "Active", "Premium", 980, "2028-01-20")
    )

    override fun getSchools(): List<SchoolRecord> = schools

    override fun addSchool(name: String, tier: String): SchoolRecord {
        val s = SchoolRecord(
            "sch-" + UUID.randomUUID().toString().take(6),
            "ISB-" + (1000..9999).random(),
            "ACC-" + (1000..9999).random(),
            name, "Active", tier, 0, "2027-12-31"
        )
        schools.add(0, s)
        return s
    }

    override fun toggleSchoolStatus(schoolId: String) {
        val idx = schools.indexOfFirst { it.id == schoolId }
        if (idx != -1) {
            val curr = schools[idx]
            schools[idx] = curr.copy(status = if (curr.status == "Active") "Suspended" else "Active")
        }
    }

    override fun getSuperAdminStats(): Map<String, String> = mapOf(
        "Total Schools" to schools.size.toString(),
        "Active Students" to "3,290",
        "Total Revenue" to "$48,650",
        "System Uptime" to "99.98%"
    )

    override fun getAuditLogs(): List<AuditLogItem> = listOf(
        AuditLogItem("lg-1", "Dr. Hersi", "Upgraded Waberi STEM to Premium", "10 mins ago", "Tier modification"),
        AuditLogItem("lg-2", "Principal Hassan", "Enrolled 24 Grade 9 Students", "1 hour ago", "Batch Enrollment"),
        AuditLogItem("lg-3", "Ustadh Farhan", "Finalized Term 2 Math Grades", "Yesterday", "Gradebook lock")
    )

    private val students = mutableListOf(
        StudentRecord("st-1", "ADM-2024-001", "PIN-8812", "Amina Abdi", "Grade 10", "A", 0.0, "Khadija Warsame", 96),
        StudentRecord("st-2", "ADM-2024-002", "PIN-4432", "Guled Mohamed", "Grade 8", "B", 45.0, "Khadija Warsame", 91),
        StudentRecord("st-3", "ADM-2024-003", "PIN-9931", "Sahra Jama", "Grade 12", "A", 120.0, "Khadija Warsame", 88)
    )

    init {
        for (i in 4..12) {
            students.add(
                StudentRecord(
                    "st-$i", "ADM-2024-0$i", "PIN-${1000+i}",
                    "Child $i Warsame", "Grade ${(i%12)+1}", "A",
                    if (i % 2 == 0) 0.0 else 50.0, "Khadija Warsame", (88..99).random()
                )
            )
        }
    }

    override fun getSchoolAdminStats(): Map<String, String> = mapOf(
        "Enrolled Students" to students.size.toString(),
        "Certified Teachers" to "42",
        "Total Classes" to "18",
        "Fees Collected" to "$18,400"
    )

    override fun getStudents(): List<StudentRecord> = students
    override fun addStudent(student: StudentRecord) { students.add(0, student) }

    override fun getTeachers(): List<TeacherRecord> = listOf(
        TeacherRecord("tc-1", "EMP-101", "Ustadh Farhan", "Mathematics", "Grade 10-A", "+252 61 5001122"),
        TeacherRecord("tc-2", "EMP-102", "Fatima Nur", "English Literature", "Grade 9-B", "+252 61 5003344"),
        TeacherRecord("tc-3", "EMP-103", "Dr. Osman Bile", "Physics & Chemistry", "Grade 11-A", "+252 61 5005566")
    )

    private val feeTransactions = mutableListOf(
        FeeTransaction("REC-9801", "Amina Abdi", 150.0, "2026-10-18", "Paid", "Term 2 Tuition"),
        FeeTransaction("REC-9802", "Guled Mohamed", 100.0, "2026-10-17", "Paid", "Bus Transportation")
    )

    override fun getFeeTransactions(): List<FeeTransaction> = feeTransactions
    override fun recordPayment(receipt: FeeTransaction) { feeTransactions.add(0, receipt) }

    private val attendanceList = students.take(6).map {
        AttendanceEntry(it.id, it.fullName, it.admissionNo, "Present")
    }.toMutableList()

    override fun getAttendanceRoster(className: String): List<AttendanceEntry> = attendanceList
    override fun saveAttendance(entries: List<AttendanceEntry>) {
        attendanceList.clear()
        attendanceList.addAll(entries)
    }

    override fun getLinkedChildren(parentId: String): List<StudentRecord> =
        students.filter { it.parentName.contains("Warsame", ignoreCase = true) }

    override fun linkChild(parentId: String, schoolCode: String, admissionNo: String, pin: String): Boolean {
        val target = students.find { it.admissionNo.equals(admissionNo, ignoreCase = true) && it.verificationPin.equals(pin, ignoreCase = true) }
        return if (target != null) {
            val idx = students.indexOf(target)
            students[idx] = target.copy(parentName = "Khadija Warsame")
            true
        } else false
    }

    override fun getStudentMarks(studentId: String): List<MarkEntry> = listOf(
        MarkEntry("Algebra & Calculus", 94.5, 100.0, "A+", "Exceptional problem solving"),
        MarkEntry("Physics", 88.0, 100.0, "A", "Mastery of kinematics"),
        MarkEntry("English Academic Writing", 91.0, 100.0, "A+", "Superior essay synthesis"),
        MarkEntry("Islamic History", 96.0, 100.0, "A+", "Thorough comprehension")
    )

    override fun getStudentTimetable(studentId: String): List<TimetableSlot> = listOf(
        TimetableSlot("Mon - Thu", "07:30 - 08:30 AM", "Mathematics", "Ustadh Farhan", "Hall 3"),
        TimetableSlot("Mon - Thu", "08:35 - 09:35 AM", "Physics Lab", "Dr. Osman Bile", "Lab B"),
        TimetableSlot("Mon - Thu", "10:00 - 11:00 AM", "English Writing", "Fatima Nur", "Room 12")
    )

    override fun getAnnouncements(): List<AnnouncementItem> = listOf(
        AnnouncementItem("ann-1", "Midterm Examinations Schedule", "Examinations commence on Nov 15 across all grades.", "2 days ago", "All"),
        AnnouncementItem("ann-2", "Parent-Teacher Conference Day", "Annual conference set for Thursday afternoon.", "4 days ago", "Parents")
    )
}
