package com.isbaro.schoolmanagement.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.isbaro.schoolmanagement.model.UserRole
import com.isbaro.schoolmanagement.repository.MockSchoolRepository
import com.isbaro.schoolmanagement.ui.theme.EmeraldGreen
import com.isbaro.schoolmanagement.ui.theme.RoyalBlue

@Composable
fun StatMetricCard(title: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(RoyalBlue.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = RoyalBlue, modifier = Modifier.size(24.dp))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(title, style = MaterialTheme.typography.bodyMedium)
                Text(value, style = MaterialTheme.typography.headlineMedium, fontSize = 20.sp)
            }
        }
    }
}

@Composable
fun RoleSwitcherChipBar(onRoleSwitched: (UserRole) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val session by MockSchoolRepository.currentSession.collectAsState()

    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = RoyalBlue.copy(alpha = 0.08f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("ACTIVE VIEW: ${session?.role?.displayName?.uppercase()}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = RoyalBlue)
                Text(session?.name ?: "", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            FilledTonalButton(
                onClick = { expanded = true },
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Switch Role", fontSize = 12.sp)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                UserRole.values().forEach { role ->
                    DropdownMenuItem(
                        text = { Text(role.displayName, fontWeight = if (session?.role == role) FontWeight.Bold else FontWeight.Normal) },
                        onClick = {
                            expanded = false
                            MockSchoolRepository.switchRole(role)
                            onRoleSwitched(role)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: String) {
    val isPositive = status.equals("Active", true) || status.equals("Paid", true) || status.equals("Present", true)
    val color = if (isPositive) EmeraldGreen else MaterialTheme.colorScheme.error

    Surface(color = color.copy(alpha = 0.15f), shape = RoundedCornerShape(50.dp)) {
        Text(status.uppercase(), color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
    }
}
