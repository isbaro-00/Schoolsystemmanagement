package com.isbaro.schoolmanagement.ui.theme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = RoyalBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF1E40AF),
    secondary = EmeraldGreen,
    onSecondary = Color.White,
    tertiary = AmberGold,
    background = SurfaceBgLight,
    surface = SurfaceCardLight,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = CoralRed,
    outline = BorderLight
)

@Composable
fun IsbaroTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightColorScheme, content = content)
}
