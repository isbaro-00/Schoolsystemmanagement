package com.isbaro.schoolmanagement.model

enum class UserRole(val displayName: String) {
    SUPER_ADMIN("Super Admin"),
    SCHOOL_ADMIN("School Admin"),
    TEACHER("Teacher"),
    STUDENT("Student"),
    PARENT("Parent")
}

data class UserSession(
    val id: String,
    val name: String,
    val email: String,
    val role: UserRole,
    val schoolId: String? = null,
    val schoolName: String? = null
)

data class SchoolRecord(
    val id: String,
    val code: String,
    val accessCode: String,
    val name: String,
    val status: String,
    val tier: String,
    val studentCount: Int,
    val expiryDate: String
)

data class StudentRecord(
    val id: String,
    val admissionNo: String,
    val verificationPin: String,
    val fullName: String,
    val className: String,
    val section: String,
    val feeBalance: Double,
    val parentName: String,
    val attendancePct: Int
)

data class TeacherRecord(
    val id: String,
    val employeeCode: String,
    val name: String,
    val subject: String,
    val assignedClass: String,
    val phone: String
)

data class AttendanceEntry(
    val studentId: String,
    val studentName: String,
    val admissionNo: String,
    var status: String,
    var note: String = ""
)

data class MarkEntry(
    val subject: String,
    val score: Double,
    val maxScore: Double,
    val grade: String,
    val remarks: String
)

data class TimetableSlot(
    val day: String,
    val time: String,
    val subject: String,
    val teacher: String,
    val room: String
)

data class FeeTransaction(
    val receiptNo: String,
    val studentName: String,
    val amount: Double,
    val date: String,
    val status: String,
    val description: String
)

data class AnnouncementItem(
    val id: String,
    val title: String,
    val summary: String,
    val date: String,
    val targetRole: String
)

data class AuditLogItem(
    val id: String,
    val actor: String,
    val action: String,
    val timestamp: String,
    val details: String
)
