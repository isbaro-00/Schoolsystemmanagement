package com.isbaro.schoolmanagement.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.isbaro.schoolmanagement.model.UserRole
import com.isbaro.schoolmanagement.repository.MockSchoolRepository
import com.isbaro.schoolmanagement.ui.navigation.navigateToRole
import com.isbaro.schoolmanagement.ui.theme.RoyalBlue

@Composable
fun LoginScreen(navController: NavController) {
    var email by remember { mutableStateOf("yahy38989@gmail.com") }
    var password by remember { mutableStateOf("somalia1977") }
    var selectedRole by remember { mutableStateOf(UserRole.SUPER_ADMIN) }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.School, contentDescription = null, tint = RoyalBlue, modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(12.dp))
        Text("Isbaro SMS", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = RoyalBlue)
        Text("Complete School System", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(24.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Select Demo Persona:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    UserRole.values().take(3).forEach { r ->
                        FilterChip(
                            selected = selectedRole == r,
                            onClick = { selectedRole = r },
                            label = { Text(r.displayName.take(8), fontSize = 11.sp) }
                        )
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    UserRole.values().takeLast(2).forEach { r ->
                        FilterChip(
                            selected = selectedRole == r,
                            onClick = { selectedRole = r },
                            label = { Text(r.displayName, fontSize = 11.sp) }
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email Address") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
        Spacer(Modifier.height(20.dp))

        Button(
            onClick = {
                MockSchoolRepository.switchRole(selectedRole)
                navController.navigateToRole(selectedRole)
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Sign In (${selectedRole.displayName})", fontSize = 16.sp)
        }
    }
}
