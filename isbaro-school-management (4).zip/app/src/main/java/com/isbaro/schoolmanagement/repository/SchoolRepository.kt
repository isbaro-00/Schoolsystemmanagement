package com.isbaro.schoolmanagement.repository

import com.isbaro.schoolmanagement.model.*
import kotlinx.coroutines.flow.StateFlow

interface SchoolRepository {
    val currentSession: StateFlow<UserSession?>
    fun switchRole(role: UserRole)
    fun getSchools(): List<SchoolRecord>
    fun addSchool(name: String, tier: String): SchoolRecord
    fun toggleSchoolStatus(schoolId: String)
    fun getSuperAdminStats(): Map<String, String>
    fun getAuditLogs(): List<AuditLogItem>
    
    fun getSchoolAdminStats(): Map<String, String>
    fun getStudents(): List<StudentRecord>
    fun addStudent(student: StudentRecord)
    fun getTeachers(): List<TeacherRecord>
    fun getFeeTransactions(): List<FeeTransaction>
    fun recordPayment(receipt: FeeTransaction)
    
    fun getAttendanceRoster(className: String): List<AttendanceEntry>
    fun saveAttendance(entries: List<AttendanceEntry>)
    
    fun getLinkedChildren(parentId: String): List<StudentRecord>
    fun linkChild(parentId: String, schoolCode: String, admissionNo: String, pin: String): Boolean
    fun getStudentMarks(studentId: String): List<MarkEntry>
    fun getStudentTimetable(studentId: String): List<TimetableSlot>
    fun getAnnouncements(): List<AnnouncementItem>
}
