package com.isbaro.schoolmanagement.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.isbaro.schoolmanagement.repository.MockSchoolRepository
import com.isbaro.schoolmanagement.ui.common.RoleSwitcherChipBar
import com.isbaro.schoolmanagement.ui.navigation.navigateToRole

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherScreen(navController: NavController) {
    val roster = remember { mutableStateListOf(*MockSchoolRepository.getAttendanceRoster("Grade 10-A").toTypedArray()) }
    var msg by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Teacher Portal — Grade 10-A") }) },
        bottomBar = {
            Surface(tonalElevation = 6.dp) {
                Button(
                    onClick = {
                        MockSchoolRepository.saveAttendance(roster.toList())
                        msg = "Daily roll call submitted successfully!"
                    },
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Submit Daily Attendance")
                }
            }
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).fillMaxSize()) {
            item { RoleSwitcherChipBar(onRoleSwitched = { navController.navigateToRole(it) }) }
            msg?.let {
                item {
                    Text(it, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
                }
            }
            itemsIndexed(roster) { index, entry ->
                Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), shape = RoundedCornerShape(12.dp)) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(entry.studentName, fontWeight = FontWeight.Bold)
                            Text("Adm: ${entry.admissionNo}", style = MaterialTheme.typography.bodyMedium)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("Present" to "P", "Absent" to "A", "Late" to "L").forEach { (st, tag) ->
                                FilterChip(
                                    selected = entry.status == st,
                                    onClick = { roster[index] = entry.copy(status = st) },
                                    label = { Text(tag) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
