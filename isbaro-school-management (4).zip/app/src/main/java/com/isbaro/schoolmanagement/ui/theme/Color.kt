package com.isbaro.schoolmanagement.ui.theme
import androidx.compose.ui.graphics.Color
val DeepNavy = Color(0xFF0F172A)
val RoyalBlue = Color(0xFF2563EB)
val LightBlue = Color(0xFF38BDF8)
val EmeraldGreen = Color(0xFF10B981)
val CoralRed = Color(0xFFEF4444)
val AmberGold = Color(0xFFF59E0B)
val SurfaceBgLight = Color(0xFFF8FAFC)
val SurfaceCardLight = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF64748B)
val BorderLight = Color(0xFFE2E8F0)
