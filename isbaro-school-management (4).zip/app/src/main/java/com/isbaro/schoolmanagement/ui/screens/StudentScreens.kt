package com.isbaro.schoolmanagement.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Grade
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.isbaro.schoolmanagement.repository.MockSchoolRepository
import com.isbaro.schoolmanagement.ui.common.RoleSwitcherChipBar
import com.isbaro.schoolmanagement.ui.common.StatMetricCard
import com.isbaro.schoolmanagement.ui.navigation.navigateToRole

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentScreen(navController: NavController) {
    val timetable = remember { MockSchoolRepository.getStudentTimetable("st-1") }
    val marks = remember { MockSchoolRepository.getStudentMarks("st-1") }

    Scaffold(topBar = { TopAppBar(title = { Text("Student Portal") }) }) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).fillMaxSize()) {
            item { RoleSwitcherChipBar(onRoleSwitched = { navController.navigateToRole(it) }) }
            item {
                Column(Modifier.padding(16.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatMetricCard("My Attendance", "96%", Icons.Default.CalendarMonth, modifier = Modifier.weight(1f))
                        StatMetricCard("Average", "93.5%", Icons.Default.Grade, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Daily Timetable", style = MaterialTheme.typography.titleLarge)
                }
            }
            items(timetable) { slot ->
                Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), shape = RoundedCornerShape(12.dp)) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(slot.subject, fontWeight = FontWeight.Bold)
                            Text("${slot.teacher} • ${slot.room}", style = MaterialTheme.typography.bodyMedium)
                        }
                        Text(slot.time, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
            item {
                Spacer(Modifier.height(16.dp))
                Text("Examination Results", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 16.dp))
            }
            items(marks) { mark ->
                Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), shape = RoundedCornerShape(12.dp)) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(mark.subject, fontWeight = FontWeight.Bold)
                        Text("${mark.score} (${mark.grade})", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
