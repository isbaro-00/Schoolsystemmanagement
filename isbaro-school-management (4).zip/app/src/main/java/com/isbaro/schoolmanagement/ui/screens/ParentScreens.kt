package com.isbaro.schoolmanagement.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.isbaro.schoolmanagement.model.StudentRecord
import com.isbaro.schoolmanagement.repository.MockSchoolRepository
import com.isbaro.schoolmanagement.ui.common.RoleSwitcherChipBar
import com.isbaro.schoolmanagement.ui.common.StatMetricCard
import com.isbaro.schoolmanagement.ui.navigation.navigateToRole

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParentScreen(navController: NavController) {
    var refreshKey by remember { mutableIntStateOf(0) }
    val children = remember(refreshKey) { MockSchoolRepository.getLinkedChildren("parent-01") }
    var selectedChildIndex by remember { mutableIntStateOf(0) }
    var showLinkChildDialog by remember { mutableStateOf(false) }

    val activeChild: StudentRecord? = children.getOrNull(selectedChildIndex.coerceIn(0, (children.size - 1).coerceAtLeast(0)))
    val marks = remember(activeChild) { activeChild?.let { MockSchoolRepository.getStudentMarks(it.id) } ?: emptyList() }
    val announcements = remember { MockSchoolRepository.getAnnouncements() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Parent Guardian Portal") },
                actions = {
                    IconButton(onClick = { showLinkChildDialog = true }) { Icon(Icons.Default.GroupAdd, "Link Child") }
                }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).fillMaxSize()) {
            item { RoleSwitcherChipBar(onRoleSwitched = { navController.navigateToRole(it) }) }
            item {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text("Linked Children (${children.size} / 100 Capacity)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        children.forEachIndexed { idx, child ->
                            FilterChip(
                                selected = idx == selectedChildIndex,
                                onClick = { selectedChildIndex = idx },
                                label = { Text("${child.fullName} (${child.className})") },
                                leadingIcon = { Icon(Icons.Default.Person, null, modifier = Modifier.size(16.dp)) }
                            )
                        }
                    }
                }
            }

            activeChild?.let { child ->
                item {
                    Column(Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatMetricCard("Attendance", "${child.attendancePct}%", Icons.Default.EventAvailable, modifier = Modifier.weight(1f))
                            StatMetricCard("Fee Balance", "$${child.feeBalance}", Icons.Default.CreditCard, modifier = Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("Report Card — ${child.fullName}", style = MaterialTheme.typography.titleLarge)
                    }
                }
                items(marks) { mark ->
                    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), shape = RoundedCornerShape(12.dp)) {
                        Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text(mark.subject, fontWeight = FontWeight.Bold)
                                Text(mark.remarks, style = MaterialTheme.typography.bodyMedium)
                            }
                            Text("${mark.score} (${mark.grade})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }

            item {
                Spacer(Modifier.height(16.dp))
                Text("School Announcements", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 16.dp))
            }
            items(announcements) { ann ->
                Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text(ann.title, fontWeight = FontWeight.Bold)
                        Text(ann.summary, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }

    if (showLinkChildDialog) {
        var schoolCode by remember { mutableStateOf("") }
        var admissionNo by remember { mutableStateOf("") }
        var pin by remember { mutableStateOf("") }
        var errorMsg by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showLinkChildDialog = false },
            title = { Text("Link Child (Up to 100)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = schoolCode, onValueChange = { schoolCode = it }, label = { Text("School Code") })
                    OutlinedTextField(value = admissionNo, onValueChange = { admissionNo = it }, label = { Text("Admission Number") })
                    OutlinedTextField(value = pin, onValueChange = { pin = it }, label = { Text("Verification PIN") })
                    errorMsg?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (MockSchoolRepository.linkChild("parent-01", schoolCode, admissionNo, pin)) {
                        refreshKey++
                        showLinkChildDialog = false
                    } else {
                        errorMsg = "Verification PIN or Admission No invalid"
                    }
                }) { Text("Link Child") }
            },
            dismissButton = { TextButton(onClick = { showLinkChildDialog = false }) { Text("Cancel") } }
        )
    }
}
