package com.isbaro.schoolmanagement.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.isbaro.schoolmanagement.model.UserRole
import com.isbaro.schoolmanagement.ui.screens.*

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object SuperAdmin : Screen("super_admin")
    object SchoolAdmin : Screen("school_admin")
    object Teacher : Screen("teacher")
    object Parent : Screen("parent")
    object Student : Screen("student")
}

fun NavController.navigateToRole(role: UserRole) {
    val target = when (role) {
        UserRole.SUPER_ADMIN -> Screen.SuperAdmin.route
        UserRole.SCHOOL_ADMIN -> Screen.SchoolAdmin.route
        UserRole.TEACHER -> Screen.Teacher.route
        UserRole.PARENT -> Screen.Parent.route
        UserRole.STUDENT -> Screen.Student.route
    }
    navigate(target) {
        popUpTo(Screen.Login.route) { inclusive = false }
        launchSingleTop = true
    }
}

@Composable
fun AppNavHost(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Screen.Login.route) {
        composable(Screen.Login.route) { LoginScreen(navController) }
        composable(Screen.SuperAdmin.route) { SuperAdminScreen(navController) }
        composable(Screen.SchoolAdmin.route) { SchoolAdminScreen(navController) }
        composable(Screen.Teacher.route) { TeacherScreen(navController) }
        composable(Screen.Parent.route) { ParentScreen(navController) }
        composable(Screen.Student.route) { StudentScreen(navController) }
    }
}
