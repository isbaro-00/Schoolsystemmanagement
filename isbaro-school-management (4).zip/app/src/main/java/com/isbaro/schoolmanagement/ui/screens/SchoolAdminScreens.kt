package com.isbaro.schoolmanagement.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.isbaro.schoolmanagement.model.StudentRecord
import com.isbaro.schoolmanagement.repository.MockSchoolRepository
import com.isbaro.schoolmanagement.ui.common.RoleSwitcherChipBar
import com.isbaro.schoolmanagement.ui.common.StatMetricCard
import com.isbaro.schoolmanagement.ui.navigation.navigateToRole

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SchoolAdminScreen(navController: NavController) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var showEnrollDialog by remember { mutableStateOf(false) }
    var refreshKey by remember { mutableIntStateOf(0) }

    val stats = remember(refreshKey) { MockSchoolRepository.getSchoolAdminStats() }
    val students = remember(refreshKey) { MockSchoolRepository.getStudents() }
    val teachers = remember(refreshKey) { MockSchoolRepository.getTeachers() }
    val fees = remember(refreshKey) { MockSchoolRepository.getFeeTransactions() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("School Admin Console") },
                actions = {
                    IconButton(onClick = { showEnrollDialog = true }) { Icon(Icons.Default.PersonAdd, "Enroll Student") }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            RoleSwitcherChipBar(onRoleSwitched = { navController.navigateToRole(it) })
            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Overview") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Students") })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Faculty") })
                Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Ledger") })
            }

            when (selectedTab) {
                0 -> {
                    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatMetricCard("Students", stats["Enrolled Students"] ?: "0", Icons.Default.School, modifier = Modifier.weight(1f))
                                StatMetricCard("Teachers", stats["Certified Teachers"] ?: "0", Icons.Default.Badge, modifier = Modifier.weight(1f))
                            }
                            Spacer(Modifier.height(10.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatMetricCard("Classes", stats["Total Classes"] ?: "0", Icons.Default.MeetingRoom, modifier = Modifier.weight(1f))
                                StatMetricCard("Collected", stats["Fees Collected"] ?: "$0", Icons.Default.Payments, modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
                1 -> {
                    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
                        items(students) { st ->
                            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(12.dp)) {
                                Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column {
                                        Text(st.fullName, fontWeight = FontWeight.Bold)
                                        Text("Adm: ${st.admissionNo} • ${st.className}-${st.section}", style = MaterialTheme.typography.bodyMedium)
                                        Text("Parent PIN: ${st.verificationPin}", color = MaterialTheme.colorScheme.primary)
                                    }
                                    Text("$${st.feeBalance}", fontWeight = FontWeight.Bold, color = if (st.feeBalance > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary)
                                }
                            }
                        }
                    }
                }
                2 -> {
                    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
                        items(teachers) { tc ->
                            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(12.dp)) {
                                Column(Modifier.padding(14.dp)) {
                                    Text(tc.name, fontWeight = FontWeight.Bold)
                                    Text("${tc.subject} Specialist • ${tc.assignedClass}", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                }
                3 -> {
                    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
                        items(fees) { f ->
                            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(12.dp)) {
                                Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column {
                                        Text(f.studentName, fontWeight = FontWeight.Bold)
                                        Text("${f.receiptNo} • ${f.description}", style = MaterialTheme.typography.bodyMedium)
                                    }
                                    Text("+$${f.amount}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEnrollDialog) {
        var name by remember { mutableStateOf("") }
        var grade by remember { mutableStateOf("Grade 10") }
        AlertDialog(
            onDismissRequest = { showEnrollDialog = false },
            title = { Text("Enroll Student") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Full Name") })
                    OutlinedTextField(value = grade, onValueChange = { grade = it }, label = { Text("Grade") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) {
                        MockSchoolRepository.addStudent(
                            StudentRecord("st-${(100..999).random()}", "ADM-2026-${(1000..9999).random()}", "PIN-${(1000..9999).random()}", name, grade, "A", 0.0, "Khadija Warsame", 100)
                        )
                        refreshKey++
                        showEnrollDialog = false
                    }
                }) { Text("Enroll") }
            },
            dismissButton = { TextButton(onClick = { showEnrollDialog = false }) { Text("Cancel") } }
        )
    }
}
