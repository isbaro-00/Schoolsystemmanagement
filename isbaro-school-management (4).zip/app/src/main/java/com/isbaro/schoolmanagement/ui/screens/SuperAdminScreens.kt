package com.isbaro.schoolmanagement.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.isbaro.schoolmanagement.repository.MockSchoolRepository
import com.isbaro.schoolmanagement.ui.common.RoleSwitcherChipBar
import com.isbaro.schoolmanagement.ui.common.StatMetricCard
import com.isbaro.schoolmanagement.ui.common.StatusBadge
import com.isbaro.schoolmanagement.ui.navigation.navigateToRole

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SuperAdminScreen(navController: NavController) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedTierFilter by remember { mutableStateOf("All") }
    var showAddSchoolDialog by remember { mutableStateOf(false) }
    var refreshTrigger by remember { mutableIntStateOf(0) }

    val stats = remember(refreshTrigger) { MockSchoolRepository.getSuperAdminStats() }
    val schools = remember(refreshTrigger, searchQuery, selectedTierFilter) {
        MockSchoolRepository.getSchools().filter {
            (selectedTierFilter == "All" || it.tier.equals(selectedTierFilter, ignoreCase = true)) &&
            (it.name.contains(searchQuery, ignoreCase = true) || it.code.contains(searchQuery, ignoreCase = true))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Super Admin Platform", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { showAddSchoolDialog = true }) {
                        Icon(Icons.Default.AddBusiness, contentDescription = "Register School")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).fillMaxSize()) {
            item { RoleSwitcherChipBar(onRoleSwitched = { navController.navigateToRole(it) }) }
            item {
                Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatMetricCard("Schools", stats["Total Schools"] ?: "0", Icons.Default.CorporateFare, modifier = Modifier.weight(1f))
                    StatMetricCard("Revenue", stats["Total Revenue"] ?: "$0", Icons.Default.AccountBalanceWallet, modifier = Modifier.weight(1f))
                }
            }
            item {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Text("School Directory", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = searchQuery, onValueChange = { searchQuery = it },
                        modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search school...") },
                        leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                }
            }
            items(schools) { school ->
                Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(school.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            StatusBadge(school.status)
                        }
                        Text("Code: ${school.code} • Access Pin: ${school.accessCode}", style = MaterialTheme.typography.bodyMedium)
                        Text("Tier: ${school.tier} • Expires: ${school.expiryDate}", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { MockSchoolRepository.toggleSchoolStatus(school.id); refreshTrigger++ }) {
                            Text(if (school.status == "Active") "Suspend" else "Activate")
                        }
                    }
                }
            }
        }
    }

    if (showAddSchoolDialog) {
        var schoolName by remember { mutableStateOf("") }
        var selectedTier by remember { mutableStateOf("Standard") }
        AlertDialog(
            onDismissRequest = { showAddSchoolDialog = false },
            title = { Text("Register New School") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = schoolName, onValueChange = { schoolName = it }, label = { Text("School Name") })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Basic", "Standard", "Premium").forEach { t ->
                            FilterChip(selected = selectedTier == t, onClick = { selectedTier = t }, label = { Text(t) })
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (schoolName.isNotBlank()) {
                        MockSchoolRepository.addSchool(schoolName, selectedTier)
                        refreshTrigger++
                        showAddSchoolDialog = false
                    }
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showAddSchoolDialog = false }) { Text("Cancel") } }
        )
    }
}
