# Isbaro School Management System (Isbaro SMS)

Modern Multi-Tenant School ERP & Student Information System built with **Kotlin**, **Jetpack Compose**, and **Material 3**.

## Roles Supported
1. **Super Admin**: Multi-school tenancy, tenant provisioning, system uptime, revenue analytics, audit trail.
2. **School Admin**: Student rosters, faculty assignment, class timetable, fee collection ledger.
3. **Teacher**: Instant roll-call attendance with status tracking, gradebook submissions.
4. **Parent**: Multi-child linking (supports up to 100 children per parent), verification PIN linking, live report cards, payment tracking.
5. **Student**: Class schedules, grades, attendance percentage.

## Quick Start on Android
1. Push this project to a new GitHub repository: `isbaro-sms`
2. GitHub Actions will trigger `.github/workflows/build-apk.yml` automatically.
3. After 2–3 minutes, download `isbaro-sms-debug-apk` under GitHub Actions Artifacts and install on your Android device.

## Local Development
- Android Studio Iguana / Jellyfish (2024.1+)
- JDK 17
- Android SDK 34 (minSdk 26)
